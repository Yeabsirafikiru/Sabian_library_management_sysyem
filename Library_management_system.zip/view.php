<?php
require_once __DIR__ . '/includes/config.php';

if (!isset($_GET['id'])) {
  redirect('/books.php');
}

$book_id = (int)$_GET['id'];

try {
  // Increment view count
  $db->exec("UPDATE books SET views = views + 1 WHERE id = $book_id");

  // Get book details
  $stmt = $db->prepare("SELECT b.*, c.name as category_name FROM books b
  LEFT JOIN categories c ON b.category_id = c.id
  WHERE b.id = ?");
  $stmt->execute([$book_id]);
  $book = $stmt->fetch();

  if (!$book) {
    throw new Exception("Book not found");
  }

} catch (Exception $e) {
  $_SESSION['error'] = $e->getMessage();
  redirect('/books.php');
}

$pageTitle = "Preview: " . htmlspecialchars($book['title']);
require_once __DIR__ . '/includes/header.php';
?>

<section class="book-preview">
  <div class="book-header">
    <?php if ($book['cover_image']): ?>
    <img style="max-width: 250px; display: inline-block; margin: auto;" src="<?= htmlspecialchars($book['cover_image']) ?>" class="book-cover-large">
    <?php endif; ?>

    <div class="book-meta">
      <h1><?= htmlspecialchars($book['title']) ?></h1>
      <p class="author" style="overflow: visible; margin-block: 10px; text-decoration: underline; text-transform: Capitalize;">
        By: <?= htmlspecialchars($book['author']) ?>
      </p>

      <?php if ($book['category_name']): ?>
      <p class="category">
        Category: <?= htmlspecialchars($book['category_name']) ?>
      </p>
      <?php endif; ?>

      <p class="views">
        <?= $book['views'] ?> views
      </p>

      <div class="action-buttons">
        <a href="read.php?id=<?= $book['id'] ?>" class="btn">Read Now</a>
        <a href="download.php?id=<?= $book['id'] ?>" class="btn">Download</a>
        <a href="books.php" class="btn secondary">Back to Collection</a>
      </div>
    </div>
  </div>

  <div class="book-description">
    <h2>Description</h2>
    <p>
      <?= nl2br(htmlspecialchars($book['description'] ?? 'No description available')) ?>
    </p>
  </div>

  <div class="book-preview-content">
    <h2>Preview</h2>
    <div class="pdf-preview">
      <embed src="<?= htmlspecialchars($book['file_path']) ?>#toolbar=0&navpanes=0&scrollbar=0&view=FitH" type="application/pdf" width="100%" height="600px">
    </div>
  </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>